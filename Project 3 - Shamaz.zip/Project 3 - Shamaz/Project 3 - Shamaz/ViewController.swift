//
//  ViewController.swift
//  Project 3 - Shamaz
//
//  Created by julian farges on 26/09/2018.
//  Copyright © 2018 julian farges. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let pastStory = ["Describe your day", "Describe your morning", "Describe your evening","what was the most interesting thing you did","how did you feel","Describe your dinner","Describe your mental state"]
    
    let timestampPast = ["2 days ago","2 weeks ago","5 days ago","3 days ago","yesterday","4 days ago","6 days ago","1 week ago","3 weeks ago","10 days ago"]
    
    let futureStory = ["where would you like to be","what would you like to be doing","how do you imagine your life","what is your plans","how do you imagine your current job situation","what dreams would you like to accomplish","what goals do you have"]
    
    let timestampFuture = ["a week from now","2 weeks from now","3 weeks from now","a month from now","2 month from now","3 month from now","4 month from now","6 month from now","a year from now","2 years from now","10 years from now"]
    
    
    @IBOutlet weak var experiance: UILabel!
    
    //Pastexperiance button that will generate a question concerning the past
    @IBAction func PastExperiance() {
        
        
        //Generate random Past story
        let pstoryRandomindex = Int(arc4random_uniform(UInt32(pastStory.count)))
        let randompstory = pastStory[pstoryRandomindex]
        print(randompstory)
        
        
        //Generate random past timestamp
        let timepRandomindex = Int(arc4random_uniform(UInt32(timestampPast.count)))
        let randomtimep = timestampPast[timepRandomindex]
        print(randomtimep)
        
        let newexperiancep = randompstory + " " + randomtimep
        
        experiance.text = newexperiancep
    }
    //FuturePlans button that will generate a question concerning the future
    @IBAction func FuturePlans() {
        
       
        //Generate random future story
        let fstoryRandomindex = Int(arc4random_uniform(UInt32(futureStory.count)))
        let randomfstory = futureStory[fstoryRandomindex]
        print(randomfstory)
        
        //Generate random future timestamp
        let timefRandomindex = Int(arc4random_uniform(UInt32(timestampFuture.count)))
        let randomtimef = timestampFuture[timefRandomindex]
        print(randomtimef)
        
        let newexperiancef = randomfstory + " " + randomtimef
        
        experiance.text = newexperiancef
    }
    
    //who's next button will generate a random number to designate the next person to play.
    @IBAction func whosnext() {
        
        //Generate Random number between 0 and 10 for who's next function
        let nextb = Int(arc4random_uniform(UInt32(11)))
        experiance.text = String(nextb)
    }
    
    //Reset button will reset the displayed text to the initial text, if players which to take a break playing.
    @IBAction func reset() {
        
        // Reset Button to get back to starting point
        let reset = "Share your past and future..."
        experiance.text = reset
        print(reset)
    }
}
